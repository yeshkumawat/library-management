u=4
i=1
while i<11:
    print(i*4)
    i=i+1